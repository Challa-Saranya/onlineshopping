package com.online.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.bean.AdminDetails;
import com.online.dao.AdminDao;
@Service
public class AdminServiceImpl implements AdminService {
@Autowired
AdminDao admindao;
	
	@Override
	public String createAdmin(AdminDetails admindetails) {
		// TODO Auto-generated method stub
		return admindao.createAdmin(admindetails);
	}

	@Override
	public List<AdminDetails> getAllAdmin() {
		// TODO Auto-generated method stub
		return admindao.getAllAdmin();
	}

	@Override
	public AdminDetails getByAdminId(int id) {
		// TODO Auto-generated method stub
		return admindao.getByAdminId(id);
	}

	@Override
	public List<AdminDetails> getByName(String name) {
		// TODO Auto-generated method stub
		return admindao.getByName(name);
	}

	@Override
	public Integer deletecart(String id) {
		// TODO Auto-generated method stub
		return admindao.deletecart(id);
	}

}
