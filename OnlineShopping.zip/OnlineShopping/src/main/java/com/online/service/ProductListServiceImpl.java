package com.online.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.bean.ProductDetails;
import com.online.dao.ProductListDao;
@Service
public class ProductListServiceImpl implements ProductListService {

	@Autowired
ProductListDao productlistdao;
	
	@Override
	public ProductDetails createProductDetails(ProductDetails productlist) {
		// TODO Auto-generated method stub
		return productlistdao.createProductDetails(productlist);
	}

	@Override
	public List<ProductDetails> getAllProduct() {
		// TODO Auto-generated method stub
		return productlistdao.getAllProduct();
	}

	@Override
	public ProductDetails getByProductId(int id) {
		// TODO Auto-generated method stub
		return productlistdao.getByProductId(id);
	}

	@Override
	public ProductDetails getByName(String name) {
		// TODO Auto-generated method stub
		return productlistdao.getByName(name);
	}

	@Override
	public List<ProductDetails> getByProductPrice(String price) {
		// TODO Auto-generated method stub
		return productlistdao.getByProductPrice(price);
	}

	@Override
	public List<ProductDetails> getByProductCategory(String category) {
		// TODO Auto-generated method stub
		return productlistdao.getByProductCategory(category);
	}

	@Override
	public List<ProductDetails> searchByCategoryandPrice(String search) {
		// TODO Auto-generated method stub
		return productlistdao.searchByCategoryandPrice(search);
	}
	

}
