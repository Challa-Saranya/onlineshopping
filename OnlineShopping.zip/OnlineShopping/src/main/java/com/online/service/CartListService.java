package com.online.service;

import java.util.List;

import com.online.bean.CartDetails;
import com.online.bean.ProductDetails;

public interface CartListService {
	void addToCart1(ProductDetails productDetails);
	List<CartDetails> getAllCart();
	Integer deletecart(String id);

}
