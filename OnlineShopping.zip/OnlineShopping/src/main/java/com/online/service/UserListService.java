package com.online.service;

import java.util.List;

import com.online.bean.UserDetails;

public interface UserListService {
	String createUser(UserDetails userlist);
	List<UserDetails> getAllUser();
	UserDetails getByUserId(int id);
	List<UserDetails> getByName(String name);
	Integer validateByMailPswd(String mailId,String pswd);
}
