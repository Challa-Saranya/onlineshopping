package com.online.service;

import java.util.List;

import com.online.bean.AdminDetails;


public interface AdminService {
	String createAdmin(AdminDetails admindetails);
	
	List<AdminDetails> getAllAdmin();
	
	AdminDetails getByAdminId(int id);
	
	List<AdminDetails> getByName(String name);
	
	Integer deletecart(String id);

}
