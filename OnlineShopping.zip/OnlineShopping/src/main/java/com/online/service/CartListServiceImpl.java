package com.online.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.online.bean.CartDetails;
import com.online.bean.ProductDetails;
import com.online.dao.CartListDao;

@Service
public class CartListServiceImpl implements CartListService {

	
	@Autowired
	CartListDao cartlistdao;
	@Override
	public void addToCart1(ProductDetails productDetails) {
		// TODO Auto-generated method stub
		System.out.println("in service");
		cartlistdao.addToCart1(productDetails);
		
	}
	@Override
	public List<CartDetails> getAllCart() {
		// TODO Auto-generated method stub
		return cartlistdao.getAllCart();
	}
	@Override
	public Integer deletecart(String id) {
		// TODO Auto-generated method stub
		System.out.println("on service");
		return cartlistdao.deletecart(id);
	}
	


}
