package com.online.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.online.bean.AdminDetails;
import com.online.bean.ProductDetails;
import com.online.bean.UserDetails;
@Repository
public class AdminListdaoImpl implements AdminDao{
@Autowired
MongoTemplate mongotemplate;
	
	@Override
	public String createAdmin(AdminDetails admindetails) {
		// TODO Auto-generated method stub
		mongotemplate.insert(admindetails);
		return "succes";
	}

	@Override
	public List<AdminDetails> getAllAdmin() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(AdminDetails.class);
	}

	@Override
	public AdminDetails getByAdminId(int id) {
		// TODO Auto-generated method stub
		return mongotemplate.findById(id, AdminDetails.class);
	}

	@Override
	public List<AdminDetails> getByName(String name) {
		// TODO Auto-generated method stub
		List<AdminDetails> admins=mongotemplate.findAll(AdminDetails.class);
		List<AdminDetails> a=new ArrayList<AdminDetails>();
		for(AdminDetails admin:admins) {
			if(admin.getName().equals(name))
				a.add(admin);
		}
		return a;
	}

	@Override
	public Integer deletecart(String id) {
		// TODO Auto-generated method stub
		System.out.println("innnn");
		ProductDetails productdetails= mongotemplate.findById(id,ProductDetails.class);
		System.out.println(productdetails);
	    mongotemplate.remove(productdetails);
		return Integer.parseInt(id);
	}
}
