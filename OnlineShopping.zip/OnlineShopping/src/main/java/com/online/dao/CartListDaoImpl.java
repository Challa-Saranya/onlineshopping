package com.online.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.ConvertOperators.ToInt;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.online.bean.CartDetails;
import com.online.bean.ProductDetails;

@Repository
public class CartListDaoImpl implements CartListDao{

	@Autowired
	MongoTemplate mongotemplate;
	@Autowired
	ProductListDao prodao;
	static double  cartprice=0;
	CartDetails cart=new CartDetails();

	
	@Override
	public void addToCart1(ProductDetails productdetails) {
		// TODO Auto-generated method stub
		List<ProductDetails> prolist=new ArrayList<ProductDetails>();
		
		System.out.println("in dao");
		prolist.add(productdetails);
		
		for (ProductDetails productDetails2 : prolist) {
			String p=productDetails2.getProPrice();
			Double price=Double.parseDouble(p);
			cartprice=price+cartprice;
			System.out.println(cartprice);
			
		}
		//cart.setTotalPrice(0.0);
		
		
		 
		
		/*Query query=new Query();
		query.addCriteria(Criteria.where("proId").is(id));
		List<ProductDetails> productDetails=mongotemplate.find(query, ProductDetails.class);*/
		
        //ProductDetails productdetails1=new ProductDetails();
		
		cart.setQuantity(1);
		
		cart.setTotalPrice(cartprice);
		// val= cart.getTotalPrice();
		
		System.out.println("gggggggggg"+cart.getTotalPrice());
		//System.out.println("gggggggggg"+val);
		cart.setProductdetails1(prolist);
		mongotemplate.insert(cart);
		
	}
	@Override
	public List<CartDetails> getAllCart() {
		// TODO Auto-generated method stub
		System.out.println(mongotemplate.findAll(CartDetails.class));
		return mongotemplate.findAll(CartDetails.class);
	}
	@Override
	public Integer deletecart(String id) {
		// TODO Auto-generated method stub
		System.out.println("innnn");
		ProductDetails productdetails= mongotemplate.findById(id,ProductDetails.class);
		System.out.println(productdetails);
	    mongotemplate.remove(productdetails);
		return Integer.parseInt(id);
	}

}
