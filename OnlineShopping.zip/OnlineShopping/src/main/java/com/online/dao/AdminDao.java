package com.online.dao;

import java.util.List;

import com.online.bean.AdminDetails;
import com.online.bean.UserDetails;

public interface AdminDao {

	String createAdmin(AdminDetails admindetails);
	
	List<AdminDetails> getAllAdmin();
	
	AdminDetails getByAdminId(int id);
	
	List<AdminDetails> getByName(String name);
	
	Integer deletecart(String id);
}
