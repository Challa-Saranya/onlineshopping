package com.online.dao;

import java.util.List;

import com.online.bean.UserDetails;

public interface UserListDao {
	String createUser(UserDetails userlist);
	List<UserDetails> getAllUser();
	UserDetails getByUserId(int id);
	List<UserDetails> getByName(String name);
	Integer validateByMailPswd(String mailId,String pswd);
}
