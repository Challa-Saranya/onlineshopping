package com.online.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="cartdetails")
public class CartDetails {

	private Double totalPrice;
	private Integer quantity;
	private List<ProductDetails> productdetails1;
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public List<ProductDetails> getProductdetails1() {
		return productdetails1;
	}
	public void setProductdetails1(List<ProductDetails> productdetails1) {
		this.productdetails1 = productdetails1;
	}
	public CartDetails(Double totalPrice, Integer quantity, List<ProductDetails> productdetails1) {
		super();
		this.totalPrice = totalPrice;
		this.quantity = quantity;
		this.productdetails1 = productdetails1;
	}
	@Override
	public String toString() {
		return "CartDetails [totalPrice=" + totalPrice + ", quantity=" + quantity + ", productdetails1="
				+ productdetails1 + "]";
	}
	public CartDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
