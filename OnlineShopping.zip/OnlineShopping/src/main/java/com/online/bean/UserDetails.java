package com.online.bean;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="userdetails")
public class UserDetails {
	
	
	private String name;
	private String phonenumber;
	private String emailId;
	private String password;
	private String confirmPassword;
	public String getName() {
		return name;
	}
	
	

	public void setName(String name) {
		this.name = name;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	


	@Override
	public String toString() {
		return "UserDetails [name=" + name + ", phonenumber=" + phonenumber + ", emailId=" + emailId + ", password="
				+ password + ", confirmPassword=" + confirmPassword + "]";
	}



	public UserDetails(String name, String phonenumber, String emailId, String password, String confirmPassword) {
		super();
		this.name = name;
		this.phonenumber = phonenumber;
		this.emailId = emailId;
		this.password = password;
		this.confirmPassword = confirmPassword;
	}



	public UserDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
