package com.online.bean;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="admindetails")
public class AdminDetails {
	private String name;
	private String phonenumber;
	private String emailId;
	private String password;
	private String confirmPassword;
	private String userType;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	@Override
	public String toString() {
		return "UserDetails [name=" + name + ", phonenumber=" + phonenumber + ", emailId=" + emailId + ", password="
				+ password + ", confirmPassword=" + confirmPassword + ", userType=" + userType + "]";
	}
	public AdminDetails(String name, String phonenumber, String emailId, String password, String confirmPassword,
			String userType) {
		super();
		this.name = name;
		this.phonenumber = phonenumber;
		this.emailId = emailId;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.userType = userType;
	}
	public AdminDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
