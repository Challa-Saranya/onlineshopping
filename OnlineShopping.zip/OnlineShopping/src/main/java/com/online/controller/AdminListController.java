package com.online.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.online.bean.AdminDetails;
import com.online.bean.UserDetails;
import com.online.dao.AdminDao;
import com.online.service.AdminService;

@RestController
@RequestMapping("/adminlist")
@CrossOrigin(origins="http://localhost:4200")
public class AdminListController {
	@Autowired
	AdminService adminService;
	@PostMapping("/create")
	public String createAdminDetails(@RequestBody AdminDetails admindetails) {
		System.out.println("Hi");
		return adminService.createAdmin(admindetails);
	}
	
	
	@GetMapping("/get")
	public List<AdminDetails> getAdminDetails() {
		return adminService.getAllAdmin();
		} 
	
	@GetMapping("/getByAdminId")
	public AdminDetails getByAdminId(@RequestParam("id") int id)
	{
	return adminService.getByAdminId(id);
	}
	
	
	
	@GetMapping("/getByAdminName")
	public List<AdminDetails> getByName(@RequestParam("name") String name) {
		return adminService.getByName(name);
	}
	
	@DeleteMapping("/deleteproducts/{pid}")
	 public Boolean deleteProduct(@PathVariable("pid") String id)
	 {
		 System.out.println("in ccc"+id);
		 adminService.deletecart(id);
		 return true;
	 }
	
	
	
	
}
