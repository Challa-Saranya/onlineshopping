package com.online.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.online.bean.CartDetails;
import com.online.bean.ProductDetails;
import com.online.service.CartListServiceImpl;

@RestController
@RequestMapping("/cartlist")
@CrossOrigin(origins="http://localhost:4200")
public class CartListController {
	
	@Autowired
	CartListServiceImpl cartlistservice;
	CartDetails cartDetails;
	
	@PostMapping("/add")
	public void newCartlist(@RequestBody ProductDetails partdetails) {
		System.out.println("In controller jgjh");
		System.out.println("hi");
		
		System.out.println("product details"+partdetails);
	
		
		
		cartlistservice.addToCart1(partdetails);
		
		
		
	}
	
	 @GetMapping(value = "/getAll")
		public List<CartDetails> getAllDetails(){
		 System.out.println("in gett");
			return cartlistservice.getAllCart();
			
		}
	 @DeleteMapping("/deleteproduct")
	 public Boolean deleteProduct(@RequestParam("pid") String id)
	 {
		 System.out.println("in ccc");
		 cartlistservice.deletecart(id);
		 return true;
	 }
	

}
