import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {


  constructor(private userService:UserService,private productService:ProductserviceService){}
  selectedFiles: FileList;
  currentFileUpload: File;
  dataone:any[];
  proId:string;
  name:string;
  address:string;

  ngOnInit() {
    return this.userService.getdata().subscribe((data:any)=>this.dataone=data);
  }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.userService.saveProfile(this.currentFileUpload).subscribe(event => {
      
    });
 
    this.selectedFiles = undefined;
  }
  getdata(){
    console.log("hiii");
    return this.userService.getdata().subscribe((data:any)=>this.dataone=data);
}

} 



