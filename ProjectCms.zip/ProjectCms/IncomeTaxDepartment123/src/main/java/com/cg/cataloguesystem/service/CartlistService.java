package com.cg.cataloguesystem.service;

import java.util.List;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;

public interface CartlistService {
	CartDetails createCartDetails(CartDetails cartlist);
	List<CartDetails> getAllCart();
        CartDetails getByIdInCartList(int id);
        void addToCart1(String id);
        boolean addToCart(String prodId);
}
