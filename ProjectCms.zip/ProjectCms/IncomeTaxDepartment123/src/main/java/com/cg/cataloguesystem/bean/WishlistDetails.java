package com.cg.cataloguesystem.bean;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="wishlistdetails")
public class WishlistDetails {
	@Id
	private Integer wishlistId;
	private List<ProductDetails> productdetails;
	public Integer getWishlistId() {
		return wishlistId;
	}
	public void setWishlistId(Integer wishlistId) {
		this.wishlistId = wishlistId;
	}
	public List<ProductDetails> getProductdetails() {
		return productdetails;
	}
	public void setProductdetails(List<ProductDetails> productdetails) {
		this.productdetails = productdetails;
	}
	@Override
	public String toString() {
		return "WishlistDetails [wishlistId=" + wishlistId + ", productdetails=" + productdetails + "]";
	}
	public WishlistDetails(Integer wishlistId, List<ProductDetails> productdetails) {
		super();
		this.wishlistId = wishlistId;
		this.productdetails = productdetails;
	}
	public WishlistDetails() {
		super();
	}
	

}
