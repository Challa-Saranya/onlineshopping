package com.cg.cataloguesystem.dao;

import java.util.List;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.bean.ProductDetails;

public interface ProductDetailsDao {
	ProductDetails createCartDetails(ProductDetails productlist);
	List<ProductDetails> getAllProduct();
	ProductDetails getByProductId(int id);
	ProductDetails getByName(String name);
	List<ProductDetails> getByProductCategory(String category);
	List<ProductDetails> getByProductPrice(String price);
	List<ProductDetails> searchByCategoryandPrice(String search);
}
