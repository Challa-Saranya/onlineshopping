package com.cg.cataloguesystem.dao;

import java.util.List;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.bean.WishlistDetails;




public interface WishlistDao {
	WishlistDetails createWishlist(WishlistDetails wishlist);
	List<WishlistDetails> getAllWishlist();
	
	WishlistDetails getByIdInWhishList(int id);
	

}
