package com.cg.cataloguesystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.service.UserlistService;

@RestController
@RequestMapping("/userlist")
@CrossOrigin(origins="http://localhost:4200")
public class UserlistController {
	
	@Autowired
	UserlistService userlistservice;
	
	@GetMapping("/get")
	public List<UserDetails> getUserDetails() {
		return userlistservice.getAllUser();
		
	}
	@PostMapping("/create")
	public Integer createUserDetails(@RequestBody UserDetails userdetails) {
		System.out.println("Hi");
		return userlistservice.createIncomeTax(userdetails);
		
	}
	@GetMapping("/getByUserId")
	public UserDetails getByUserId(@RequestParam("id") int id)
	{
	return userlistservice.getByUserId(id);
	}

@GetMapping("/getByUserName")
public List<UserDetails> getByName(@RequestParam("name") String name) {
	return userlistservice.getByName(name);
}
@GetMapping("/validateUser/{mail}/{password}")
public Integer validateByMailPswd(@PathVariable("mail") String mailId,@PathVariable("password") String pswd) {
	return userlistservice.validateByMailPswd(mailId,pswd);
}

}
