import { Injectable } from '@angular/core';
/* import { HttpClient } from '../../node_modules/@angular/common/http'; */
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { from } from 'rxjs';
/* import { Observable} from '../../node_modules/rxjs'; */

@Injectable({
  providedIn: 'root'
})
export class OnlineserviceService {

  constructor(private httpClient:HttpClient) { }
  validateLogin(mail,password){
    console.log("In service"+mail+password)
  return this.httpClient.get("http://localhost:9633/userlist/validateUser/"+mail+"/"+password);
}
addUser(data:any){
  console.log(data);

  let input={
    "name":data.name,
    "phonenumber":data.phonenumber,
    "emailId":data.email,
    "password":data.password,
    "confirmPassword":data.confirmPassword,
    
  }

  console.log(input);
  return this.httpClient.post("http://localhost:9633/userlist/create",input);
}
getdata(){
  return this.httpClient.get("http://localhost:9633/product/getall");
}
saveProfile(file: File):Observable<any>{
  const formdata=new FormData();
  formdata.append('file',file);
  return this.httpClient.post("http://localhost:9633/product/upload",formdata, {
    reportProgress: true,
    responseType: 'text'
  });
}
}
