import { Component, OnInit } from '@angular/core';
import { OnlineserviceService } from '../onlineservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  model: any = {};
  result: number;

  constructor(private userservice: OnlineserviceService, private router: Router) { }

  ngOnInit() {
  }
  addUser(): any {
    console.log(this.model);
    this.userservice.addUser(this.model).subscribe((data: number) => {
    this.result = data;
      if (this.result == 1) {
        alert("Registration Successfull");
        this.router.navigate(['/login']);
      }
      else if (this.result == 2) {
        alert("Admin Rights are violated...you cannot register as admin");
      }
      else {
        alert("User Already Exist")
      }
    });
  }
}
