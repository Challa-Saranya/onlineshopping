import { Component, OnInit } from '@angular/core';
import { OnlineserviceService } from '../onlineservice.service';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-admin-products',
  templateUrl: './admin-products.component.html',
  styleUrls: ['./admin-products.component.css']
})
export class AdminProductsComponent implements OnInit {

  constructor(private userservice:OnlineserviceService,private productservice:ProductserviceService) { }
  selectedFiles: FileList;
  currentFileUpload: File;
  dataone:any[];
  proId:string;
  name:string;
  address:string;
  ngOnInit() {
    return this.userservice.getdata().subscribe((data:any)=>this.dataone=data);
  }
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
  upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.userservice.saveProfile(this.currentFileUpload).subscribe(event => {
      
    });
 
    this.selectedFiles = undefined;
  }
  delete(id){
    console.log(id);
    this.productservice.deletecart(id).subscribe();
    alert("Product deleted Successfully");
  }
  getdata(){
    console.log("hiii");
    return this.userservice.getdata().subscribe((data:any)=>this.dataone=data);
}
}
